         function check() {
            var tk = document.getElementById('taikhoan');
            var mk = document.getElementById('matkhau');
            var hoten = document.getElementById('hoten');
            var email = document.getElementById('email');
            var sdt = document.getElementById('sdt');
            var diachi = document.getElementById('diachi');

            if (tk.value.length < 5 || tk.value.length > 20 || tk.value.search("  " >= 0)) {
                alert('tài khoản từ 5->20 kí tự không chứa khoảng trắng và không để trống!');
                return false;
            }
            if (mk.value.length < 5 || mk.value.length > 20 || mk.value.search("  " >= 0)) {
                alert('mật khẩu có độ lớn từ 5 -> 20 và không chứa khoảng trắng !')
            }
            if (hoten == "") {
                alert('Họ tên không được để trống!')
                return false
            }
            if (!email.value.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/) || email.value.search("  " >= 0)) {
                alert('email không hợp lệ!');
                return false
            }
            if (diachi.value == "") {
                alert('địa chỉ không để trống!');
                return false
            }
            if (sdt.value.length != 10 || sdt.value.search("  " >= 0)) {
                alert('số điện thoại 10 kí tự không chứa khoảng trắng !')
                return false
            }

            alert('nhập thông tin thành công!');
        }
